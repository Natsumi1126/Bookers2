# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '9e2f95a0a77d98d5fec3b1a5611a92ecc7427e86a9457a278fdcc8b7792ce807292bfc5425611de92be24eee156bbd90bbcb4f4ae44bfbea1f375d04fcc3c499'